'use server';

import { query } from '@/lib/db';
import { revalidatePath } from 'next/cache';

const REGISTROS_POR_PAGINA = 5;

// 1. Obtener listado con soporte para búsqueda combinada (Docente o Materia)
export async function getAsignacionesPaginadas(paginaActual: number, search: string) {
    const offset = (paginaActual - 1) * REGISTROS_POR_PAGINA;
    let whereClause = '';
    let params: any[] = [];

    if (search.trim() !== '') {
        whereClause = `WHERE d.apellido ILIKE $1 OR m.nombre ILIKE $1`;
        params = [`%${search.trim()}%`];
    }

    const registrosQuery = `
        SELECT 
            a.id_asignacion, a.anio_lectivo,
            a.id_docente, a.id_materia, a.id_division,
            CONCAT(d.apellido, ', ', d.nombre) AS docente_agente, d.cuil,
            m.nombre AS materia_nombre,
            div.nombre AS division_nombre, c.nombre AS curso_nombre,
            a.situacion_revista, a.cant_hs
        FROM asignaciones a
        JOIN docentes d ON a.id_docente = d.id_docente
        JOIN materias m ON a.id_materia = m.id_materia
        JOIN divisiones div ON a.id_division = div.id_division
        JOIN cursos c ON div.id_curso = c.id_curso
        ${whereClause}
        ORDER BY a.anio_lectivo DESC, d.apellido ASC
        LIMIT ${REGISTROS_POR_PAGINA} OFFSET ${offset}
    `;

    const countQuery = `
        SELECT COUNT(*) FROM asignaciones a
        JOIN docentes d ON a.id_docente = d.id_docente
        JOIN materias m ON a.id_materia = m.id_materia
        ${whereClause}
    `;

    const registrosRes = await query(registrosQuery, params);
    const conteoRes = await query(countQuery, params);

    const totalRegistros = parseInt(conteoRes.rows[0].count, 10);
    const totalPaginas = Math.ceil(totalRegistros / REGISTROS_POR_PAGINA);

    return { asignaciones: registrosRes.rows, totalPaginas: totalPaginas || 1 };
}

export async function getCatalogosAsignaciones() {
    const docentes = await query('SELECT id_docente, apellido, nombre FROM docentes ORDER BY apellido');
    const materias = await query('SELECT id_materia, nombre FROM materias ORDER BY nombre');
    const divisiones = await query(`
        SELECT d.id_division, d.nombre AS division_nombre, c.nombre AS curso_nombre 
        FROM divisiones d JOIN cursos c ON d.id_curso = c.id_curso ORDER BY c.nombre, d.nombre
    `);
    return { docentes: docentes.rows, materias: materias.rows, divisiones: divisiones.rows };
}

// 2. Crear Asignación con Validador de Duplicados Incorporado
export async function createAsignacionGeneral(prevState: any, formData: FormData) {
    const id_docente = formData.get('id_docente');
    const id_materia = formData.get('id_materia');
    const id_division = formData.get('id_division');
    const anio_lectivo = formData.get('anio_lectivo');

    try {
        // CONSULTA DE VALIDACIÓN: Verificar si esta combinación exacta ya existe
        const checkQuery = `
            SELECT COUNT(*) FROM asignaciones 
            WHERE id_docente = $1 AND id_materia = $2 AND id_division = $3 AND anio_lectivo = $4
        `;
        const checkRes = await query(checkQuery, [id_docente, id_materia, id_division, anio_lectivo]);

        if (parseInt(checkRes.rows[0].count, 10) > 0) {
            return { error: 'Error: El docente ya se encuentra asignado a esa misma materia y división para este ciclo lectivo.' };
        }

        // Si no existe, se procede con la inserción normal
        await query(
            'INSERT INTO asignaciones (id_docente, id_materia, id_division, anio_lectivo) VALUES ($1, $2, $3, $4)',
            [id_docente, id_materia, id_division, anio_lectivo]
        );

        revalidatePath('/dashboard/asignaciones');
        return { success: true, error: null };
    } catch (error) {
        return { error: 'Ocurrió un problema de comunicación con PostgreSQL.' };
    }
}

export async function deleteAsignacionGeneral(id: number) {
    await query('DELETE FROM asignaciones WHERE id_asignacion = $1', [id]);
    revalidatePath('/dashboard/asignaciones');
}

export async function updateAsignacionGeneral(id_asignacion: number, formData: FormData) {
    const id_docente = formData.get('id_docente');
    const id_materia = formData.get('id_materia');
    const id_division = formData.get('id_division');
    const anio_lectivo = formData.get('anio_lectivo');

    try {
        // Validador: Verificar que la nueva combinación no genere un duplicado con otra asignación existente
        const checkQuery = `
            SELECT COUNT(*) FROM asignaciones 
            WHERE id_docente = $1 AND id_materia = $2 AND id_division = $3 AND anio_lectivo = $4
                AND id_asignacion != $5
        `;
        const checkRes = await query(checkQuery, [id_docente, id_materia, id_division, anio_lectivo, id_asignacion]);

        if (parseInt(checkRes.rows.count, 10) > 0) {
            return { error: 'Error: La nueva combinación elegida ya se encuentra asignada en el sistema.' };
        }

        const text = `
            UPDATE asignaciones 
            SET id_docente = $1, id_materia = $2, id_division = $3, anio_lectivo = $4
            WHERE id_asignacion = $5
        `;
        await query(text, [id_docente, id_materia, id_division, anio_lectivo, id_asignacion]);

        revalidatePath('/dashboard/asignaciones');
        return { success: true, error: null };
    } catch (error) {
        return { error: 'No se pudieron guardar los cambios en la base de datos.' };
    }
}
