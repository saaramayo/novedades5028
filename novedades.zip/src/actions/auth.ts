'use server';

import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';

// Acción para iniciar sesión
export async function loginAction(formData: FormData) {
    const username = formData.get('username') as string;
    const password = formData.get('password') as string;

    // Validación dummy de credenciales (Aquí deberías validar contra tu base de datos de PostgreSQL)
    if (username === 'admin' && password === 'Salta4118') {

        // Crear cookie HTTP-Only segura para evitar vulnerabilidades XSS
        const cookieStore = await cookies();
        cookieStore.set('session_token', 'token_seguro_de_sesion_decreto_4118', {
            httpOnly: true,
            secure: process.env.NODE_ENV === 'production', // Solo HTTPS en producción
            sameSite: 'lax',
            maxAge: 60 * 60 * 8, // Expiración en 8 horas (un turno escolar común)
            path: '/',
        });

    } else {
        // Si falla, podrías retornar un objeto de error (similar al de licencias)
        return { error: 'Credenciales inválidas' };
    }

    // Si el login es exitoso, Next.js procesa la redirección
    redirect('/dashboard');
}

// Acción para cerrar sesión
export async function logoutAction() {
    const cookieStore = await cookies();

    // Borrar la cookie del navegador
    cookieStore.delete('session_token');

    // Redireccionar al login de forma inmediata
    redirect('/login');
}
