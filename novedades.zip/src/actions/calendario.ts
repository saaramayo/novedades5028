'use server';

import { query } from '@/lib/db';

export async function getLicenciasCalendario(anio: number, mes: number) {
  try {
    // Definimos el rango del mes solicitado
    const primerDiaMes = `${anio}-${String(mes).padStart(2, '0')}-01`;
    // El truco en Postgres para el último día del mes:
    const ultimoDiaMes = `('${primerDiaMes}'::date + interval '1 month' - interval '1 day')::date`;

    const text = `
      SELECT 
        s.id_solicitud,
        s.fecha_inicio,
        s.fecha_fin,
        s.estado,
        CONCAT(d.apellido, ' ', SUBSTRING(d.nombre FROM 1 FOR 1), '.') AS docente_corto,
        tl.articulo,
        tl.goce_haberes -- Campo añadido para mapeo estético
      FROM solicitudes_licencias s
      JOIN docentes d ON s.id_docente = d.id_docente
      JOIN tipos_licencias tl ON s.id_tipo_licencia = tl.id_tipo_licencia
      WHERE 
        s.estado = 'Aprobado'
        AND s.fecha_inicio <= ${ultimoDiaMes}
        AND s.fecha_fin >= $1::date
      ORDER BY s.fecha_inicio ASC
    `;
    const res = await query(text, [primerDiaMes]);
    return res.rows;
  } catch (error) {
    console.error('Error al obtener calendario de licencias:', error);
    return [];
  }
}
