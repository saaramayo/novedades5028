'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { logoutAction } from '@/actions/auth';
import {
    Menu,
    LayoutDashboard,
    Users,
    FileText,
    RefreshCw,
    Calendar,
    LogOut,
    GraduationCap,
    BookMarked,
    CalendarRange,
    Grid3X3,
    Settings
} from 'lucide-react';

import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetTrigger,
} from "@/components/ui/sheet";

export default function MenuMovil() {
    const [open, setOpen] = useState(false);
    const pathname = usePathname();

    const enlaces = [
        { href: '/dashboard', label: 'Inicio', icon: LayoutDashboard },
        { href: '/dashboard/docentes', label: 'Agentes', icon: Users },
        { href: '/dashboard/asignaciones', label: 'Asignaciones', icon: BookMarked },
        { href: '/dashboard/distribucion', label: 'Distribución Semanal', icon: CalendarRange },
        { href: '/dashboard/grilla', label: 'Grilla Horaria', icon: Grid3X3 },
        { href: '/dashboard/tipos-licencias', label: 'Config. Artículos 4118', icon: Settings },
        { href: '/dashboard/licencias', label: 'Licencias (4118)', icon: FileText },
        { href: '/dashboard/reemplazos', label: 'Suplencias', icon: RefreshCw },
        { href: '/dashboard/calendario', label: 'Calendario Mensual', icon: Calendar },
    ];

    return (
        <Sheet open={open} onOpenChange={setOpen}>
            {/* Botón de apertura visible solo en pantallas pequeñas */}
            <SheetTrigger asChild>
                <div className="md:hidden p-2 border border-slate-200 rounded-lg bg-white text-slate-700 hover:bg-slate-50 transition-colors shadow-xs">
                    <Menu className="h-5 w-5" />
                </div>
            </SheetTrigger>

            <SheetContent side="left" className="w-64 bg-white p-6 flex flex-col justify-between h-full">
                <div className="space-y-6">
                    <SheetHeader>
                        <div className="flex items-center space-x-2 pb-4 border-b border-slate-100">
                            <div className="p-2 bg-slate-900 rounded-lg text-white">
                                <GraduationCap className="h-5 w-5" />
                            </div>
                            <SheetTitle className="text-left">
                                <span className="text-sm font-bold text-slate-900 block tracking-tight">Col. N° 5028</span>
                                <span className="text-[11px] text-slate-500 font-medium block">Reyes Católicos</span>
                            </SheetTitle>
                        </div>
                    </SheetHeader>

                    <nav className="space-y-1">
                        {enlaces.map((enlace) => {
                            const Icono = enlace.icon;
                            const activo = pathname === enlace.href;
                            return (
                                <Link
                                    key={enlace.href}
                                    href={enlace.href}
                                    onClick={() => setOpen(false)}
                                    className={`flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${activo
                                            ? 'bg-slate-100 text-slate-950 font-semibold'
                                            : 'text-slate-700 hover:bg-slate-50 hover:text-slate-950'
                                        }`}
                                >
                                    <Icono className={`mr-3 h-4 w-4 ${activo ? 'text-slate-900' : 'text-slate-500'}`} />
                                    {enlace.label}
                                </Link>
                            );
                        })}
                    </nav>
                </div>

                {/* Botón Cerrar Sesión Móvil */}
                <div className="border-t border-slate-100 pt-4">
                    <form action={logoutAction}>
                        <button className="flex w-full items-center justify-center px-3 py-2 text-sm font-semibold text-red-600 rounded-lg hover:bg-red-50 transition-colors border border-transparent hover:border-red-100">
                            <LogOut className="mr-2 h-4 w-4" />
                            Cerrar Sesión
                        </button>
                    </form>
                </div>
            </SheetContent>
        </Sheet>
    );
}
