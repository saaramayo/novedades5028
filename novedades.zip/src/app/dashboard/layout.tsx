import Link from 'next/link';
import { logoutAction } from '@/actions/auth';
import MenuMovil from '@/components/MenuMovil';
import {
    LayoutDashboard,
    Users,
    FileText,
    RefreshCw,
    Calendar,
    LogOut,
    GraduationCap,
    BookMarked,
    CalendarRange,
    Grid3X3,
    Settings
} from 'lucide-react';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
    const enlaces = [
        { href: '/dashboard', label: 'Inicio', icon: LayoutDashboard },
        { href: '/dashboard/docentes', label: 'Agentes', icon: Users },
        { href: '/dashboard/asignaciones', label: 'Asignaciones', icon: BookMarked },
        { href: '/dashboard/distribucion', label: 'Distribución Semanal', icon: CalendarRange },
        { href: '/dashboard/grilla', label: 'Grilla Horaria', icon: Grid3X3 },
        { href: '/dashboard/tipos-licencias', label: 'Config. Artículos 4118', icon: Settings },
        { href: '/dashboard/licencias', label: 'Licencias (4118)', icon: FileText },
        { href: '/dashboard/reemplazos', label: 'Suplencias', icon: RefreshCw },
        { href: '/dashboard/calendario', label: 'Calendario Mensual', icon: Calendar },
    ];

    return (
        <div className="flex h-screen bg-slate-50/50 flex-col md:flex-row overflow-hidden">

            {/* 1. BARRA SUPERIOR (MÓVIL): Visible solo en pantallas chicas (menores a md) */}
            <header className="flex md:hidden items-center justify-between p-4 bg-white border-b border-slate-200 z-40">
                <div className="flex items-center space-x-2">
                    <GraduationCap className="h-5 w-5 text-slate-900" />
                    <span className="text-sm font-bold text-slate-900 tracking-tight">Col. N° 5028</span>
                </div>
                {/* Componente del menú flotante deslizable */}
                <MenuMovil />
            </header>

            {/* 2. BARRA LATERAL (ESCRITORIO): Visible a partir de pantallas medianas (md) */}
            <aside className="hidden md:flex w-64 bg-white border-r border-slate-200 flex-col justify-between shrink-0">
                <div className="p-6">
                    <div className="flex items-center space-x-2 border-b border-slate-100 pb-5">
                        <div className="p-2 bg-slate-900 rounded-lg text-white">
                            <GraduationCap className="h-5 w-5" />
                        </div>
                        <div>
                            <h1 className="text-sm font-semibold text-slate-900 tracking-tight">Col. N° 5028</h1>
                            <p className="text-xs text-slate-500 font-medium">Reyes Católicos</p>
                        </div>
                    </div>

                    <nav className="mt-6 space-y-1">
                        {enlaces.map((enlace) => {
                            const Icono = enlace.icon;
                            return (
                                <Link
                                    key={enlace.href}
                                    href={enlace.href}
                                    className="flex items-center px-3 py-2 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100 hover:text-slate-950 transition-colors"
                                >
                                    <Icono className="mr-3 h-4 w-4 text-slate-500" />
                                    {enlace.label}
                                </Link>
                            );
                        })}
                    </nav>
                </div>

                {/* Botón de Cierre de Sesión */}
                <div className="p-4 border-t border-slate-100">
                    <form action={logoutAction}>
                        <button className="flex w-full items-center justify-center px-3 py-2 text-sm font-semibold text-red-600 rounded-md hover:bg-red-50/50 transition-colors border border-transparent hover:border-red-100">
                            <LogOut className="mr-2 h-4 w-4" />
                            Cerrar Sesión
                        </button>
                    </form>
                </div>
            </aside>

            {/* 3. CONTENEDOR DE CONTENIDO PRINCIPAL: Flexible y scrollable de forma independiente */}
            <main className="flex-1 overflow-y-auto p-4 sm:p-6 md:p-8 w-full">
                <div className="max-w-6xl mx-auto">
                    {children}
                </div>
            </main>
        </div>
    );
}
