'use client';

import { useState } from 'react';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, parseISO, addMonths, subMonths } from 'date-fns';
import { es } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, CalendarDays } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

// Función de soporte para clasificar artículos por color
const getColorClase = (articulo: string, goceHaberes: boolean) => {
    const artClean = articulo.toLowerCase().trim();

    // Licencias Médicas (Ej: Art. 24 Corto, Art. 25 Largo Tratamiento) -> Rojo / Rosa
    if (artClean.includes('22') || artClean.includes('24')) {
        return 'bg-red-50 border-red-200 text-red-800 focus:ring-red-500';
    }
    // Maternidad y Familia (Ej: Art. 42 Maternidad, Art. 43 Nacimiento) -> Púrpura
    if (artClean.includes('42') || artClean.includes('43')) {
        return 'bg-purple-50 border-purple-200 text-purple-800 focus:ring-purple-500';
    }
    // Licencias Sin Goce de Haberes (Ej: Art. 58 Razones Particulares) -> Gris / Oscuro
    if (!goceHaberes) {
        return 'bg-slate-100 border-slate-300 text-slate-700 focus:ring-slate-500';
    }
    // Otras licencias aprobadas por defecto -> Azul
    return 'bg-blue-50 border-blue-200 text-blue-800 focus:ring-blue-500';
};


export default function CalendarioClient({ initialLicencias, anioInicial, mesInicial, onMesChange }: any) {
    const [fechaActual, setFechaActual] = useState(new Date(anioInicial, mesInicial - 1, 1));
    const inicioMes = startOfMonth(fechaActual);
    const finMes = endOfMonth(fechaActual);
    const diasDelMes = eachDayOfInterval({ start: inicioMes, end: finMes });
    const diaInicioSemana = getDay(inicioMes);
    const diasFaltantesInicio = diaInicioSemana === 0 ? 6 : diaInicioSemana - 1;

    const navegarMes = (direccion: 'sig' | 'ant') => {
        const nuevaFecha = direccion === 'sig' ? addMonths(fechaActual, 1) : subMonths(fechaActual, 1);
        setFechaActual(nuevaFecha);
        onMesChange(nuevaFecha.getFullYear(), nuevaFecha.getMonth() + 1);
    };

    return (
        <div className="space-y-4">
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                {/* Cabecera del Calendario */}
                <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50/50">
                    <div className="flex items-center space-x-2">
                        <CalendarDays className="h-5 w-5 text-slate-600" />
                        <h3 className="text-lg font-bold text-slate-800 capitalize">
                            {format(fechaActual, 'MMMM yyyy', { locale: es })}
                        </h3>
                    </div>
                    <div className="flex space-x-1">
                        <button onClick={() => navegarMes('ant')} className="p-1.5 border border-slate-200 rounded-md bg-white hover:bg-slate-50">
                            <ChevronLeft className="h-4 w-4 text-slate-600" />
                        </button>
                        <button onClick={() => navegarMes('sig')} className="p-1.5 border border-slate-200 rounded-md bg-white hover:bg-slate-50">
                            <ChevronRight className="h-4 w-4 text-slate-600" />
                        </button>
                    </div>
                </div>

                {/* Días de la Semana */}
                <div className="grid grid-cols-7 border-b border-slate-100 text-center bg-slate-50/30 py-2">
                    {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(dia => (
                        <div key={dia} className="text-xs font-bold text-slate-500 uppercase tracking-wider">{dia}</div>
                    ))}
                </div>

                {/* Cuadrícula de Celdas */}
                <div className="grid grid-cols-7 auto-rows-[120px]">
                    {Array.from({ length: diasFaltantesInicio }).map((_, i) => (
                        <div key={`empty-${i}`} className="bg-slate-50/50 border-r border-b border-slate-100" />
                    ))}

                    {diasDelMes.map((dia) => {
                        const licenciasDelDia = initialLicencias.filter((lic: any) => {
                            const inicio = parseISO(new Date(lic.fecha_inicio).toISOString().split('T')[0]);
                            const fin = parseISO(new Date(lic.fecha_fin).toISOString().split('T')[0]);
                            return dia >= inicio && dia <= fin;
                        });

                        return (
                            <div key={dia.toString()} className="p-2 border-r border-b border-slate-100 last:border-r-0 flex flex-col justify-between hover:bg-slate-50/30 transition-colors">
                                <span className="text-sm font-semibold text-slate-700 font-mono">{format(dia, 'd')}</span>

                                <div className="space-y-1 overflow-y-auto max-h-[80px] pt-1">
                                    {licenciasDelDia.map((lic: any) => (
                                        <div
                                            key={lic.id_solicitud}
                                            className={`text-[10px] leading-tight font-medium border rounded p-1 truncate shadow-2xs transition-all ${getColorClase(lic.articulo, lic.goce_haberes)}`}
                                            title={`${lic.docente_corto} - ${lic.articulo}`}
                                        >
                                            <span className="font-bold mr-1">{lic.articulo}:</span>
                                            {lic.docente_corto}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* SECCIÓN NUEVA: Leyenda de Colores Estilo Shadcn UI */}
            <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs flex flex-wrap gap-4 items-center">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider mr-2">Referencias Decreto 4118:</span>

                <div className="flex items-center space-x-2">
                    <Badge className="bg-red-50 text-red-800 border-red-200 hover:bg-red-50 font-semibold rounded px-2 py-0.5 text-xs">Art. 22 / 24</Badge>
                    <span className="text-xs text-slate-600 font-medium">Razones Médicas (Carpeta Corto/Largo)</span>
                </div>

                <div className="flex items-center space-x-2">
                    <Badge className="bg-purple-50 text-purple-800 border-purple-200 hover:bg-purple-50 font-semibold rounded px-2 py-0.5 text-xs">Art. 42 / 43</Badge>
                    <span className="text-xs text-slate-600 font-medium">Maternidad, Paternidad y Familia</span>
                </div>

                <div className="flex items-center space-x-2">
                    <Badge className="bg-slate-100 text-slate-800 border-slate-200 hover:bg-slate-100 font-semibold rounded px-2 py-0.5 text-xs">Art. 74 / 99</Badge>
                    <span className="text-xs text-slate-600 font-medium">Asuntos Particulares</span>
                </div>

                <div className="flex items-center space-x-2">
                    <Badge className="bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-50 font-semibold rounded px-2 py-0.5 text-xs">Otros</Badge>
                    <span className="text-xs text-slate-600 font-medium">Mayor Jerarquía / Artículos Técnicos</span>
                </div>
            </div>
        </div>
    );
}
