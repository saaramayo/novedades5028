import { getLicenciasCalendario } from '@/actions/calendario';
import CalendarioClient from './CalendarioClient';
import { redirect } from 'next/navigation';

interface PageProps {
    searchParams: Promise<{ anio?: string; mes?: string }>;
}

export default async function CalendarioPage({ searchParams }: PageProps) {
    const resolvedParams = await searchParams;

    // Si no hay parámetros en la URL, tomamos el mes de la fecha actual del sistema
    const hoy = new Date();
    const anioActual = parseInt(resolvedParams.anio || String(hoy.getFullYear()), 10);
    const mesActual = parseInt(resolvedParams.mes || String(hoy.getMonth() + 1), 10);

    // Obtener licencias filtradas desde PostgreSQL
    //const licencias = [];
    const licencias = await getLicenciasCalendario(anioActual, mesActual);

    // Servidor redirige y muta la URL cuando el cliente hace clic en cambiar mes
    const handleMesChange = async (nuevoAnio: number, nuevoMes: number) => {
        'use server';
        redirect(`/dashboard/calendario?anio=${nuevoAnio}&mes=${nuevoMes}`);
    };

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold tracking-tight text-slate-900">Agenda Mensual de Licencias</h2>
                <p className="text-sm text-slate-500 font-medium">
                    Monitoreo y cronograma visual de ausencias aprobadas bajo el Decreto 4118/97.
                </p>
            </div>

            <CalendarioClient
                initialLicencias={licencias}
                anioInicial={anioActual}
                mesInicial={mesActual}
                onMesChange={handleMesChange}
            />
        </div>
    );
}
