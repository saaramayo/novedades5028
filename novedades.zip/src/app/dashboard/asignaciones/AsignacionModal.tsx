'use client';

import { useActionState, useEffect, useState } from 'react';
import { createAsignacionGeneral } from '@/actions/asignaciones';
import { Plus } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function AsignacionModal({ catalogos }: { catalogos: any }) {
    const [open, setOpen] = useState(false);
    const [state, formAction, isPending] = useActionState(createAsignacionGeneral, { error: null, success: false });

    // Cerrar el modal solo si se guardó con éxito sin violar el validador
    useEffect(() => {
        if (state?.success) {
            setOpen(false);
        }
    }, [state]);

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <div className="flex items-center px-4 py-2 bg-slate-900 text-white rounded-lg text-sm font-semibold hover:bg-slate-800 transition-colors shadow-sm">
                    <Plus className="w-4 h-4 mr-2" /> Nueva Asignación
                </div>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[450px] bg-white rounded-xl">
            {/*<DialogContent className="w-[95%] sm:max-w-[500px] bg-white rounded-xl gap-0 p-0 overflow-hidden">*/}
                <DialogHeader>
                    <DialogTitle className="text-lg font-bold text-slate-900">Vincular Docente a Cátedra</DialogTitle>
                    <DialogDescription className="text-xs text-slate-500">Asigne las responsabilidades académicas curriculares.</DialogDescription>
                </DialogHeader>

                <form action={formAction} className="space-y-4 pt-2">
                    {state?.error && (
                        <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-bold rounded-lg">
                            ⚠️ {state.error}
                        </div>
                    )}

                    <div className="space-y-3">
                        <select name="id_docente" required className="w-full border p-2 rounded-lg text-sm bg-white">
                            <option value="">Seleccione Docente...</option>
                            {catalogos.docentes.map((d: any) => <option key={d.id_docente} value={d.id_docente}>{d.apellido}, {d.nombre}</option>)}
                        </select>
                        <select name="id_materia" required className="w-full border p-2 rounded-lg text-sm bg-white">
                            <option value="">Seleccione Materia...</option>
                            {catalogos.materias.map((m: any) => <option key={m.id_materia} value={m.id_materia}>{m.nombre}</option>)}
                        </select>
                        <select name="id_division" required className="w-full border p-2 rounded-lg text-sm bg-white">
                            <option value="">Seleccione Curso / División...</option>
                            {catalogos.divisiones.map((d: any) => <option key={d.id_division} value={d.id_division}>{d.curso_nombre} - {d.division_nombre}</option>)}
                        </select>
                        <input type="number" name="anio_lectivo" placeholder="Ciclo Lectivo" defaultValue={new Date().getFullYear()} required className="w-full border p-2 rounded-lg text-sm" />
                    </div>
                    <div className="flex justify-end space-x-2 pt-2">
                        <button type="submit" disabled={isPending} className="px-4 py-2 bg-blue-600 text-white text-sm font-semibold rounded-lg hover:bg-blue-700">
                            {isPending ? 'Validando...' : 'Confirmar Asignación'}
                        </button>
                    </div>
                </form>
            </DialogContent>
        </Dialog>
    );
}
