import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
    // 1. Obtener la cookie de sesión (la llamamos 'session_token')
    const sessionToken = request.cookies.get('session_token')?.value;

    const { pathname } = request.nextUrl;

    // 2. Si el usuario intenta entrar al Dashboard sin estar logueado, redirigir a /login
    if (pathname.startsWith('/dashboard') && !sessionToken) {
        const loginUrl = new URL('/login', request.url);
        return NextResponse.redirect(loginUrl);
    }

    // 3. Si el usuario ya está logueado e intenta ir al login, redirigir al Dashboard
    if (pathname.startsWith('/login') && sessionToken) {
        const dashboardUrl = new URL('/dashboard', request.url);
        return NextResponse.redirect(dashboardUrl);
    }

    return NextResponse.next();
}

// 4. Configurar el Matcher para filtrar qué rutas procesa este Middleware
export const config = {
    matcher: ['/dashboard/:path*', '/login'],
};
